
#include "../h/riscv.hpp"
#include "../h/MemoryAllocator.hpp"
#include "../h/ccb.hpp"
#include "../lib/console.h"
#include "../h/MySemaphore.hpp"
#include "../test/printing.hpp"
#include "../h/MyKonzola.hpp"

void Riscv::popSppSpie() {
    //u sepc prepise kontex ra
    if(CCB::running->sisNIt){
        ms_sstatus(SSTATUS_SPP);
    } else{
        mc_sstatus(SSTATUS_SPP);
    }
    //samo kad se prvi put ulazi u odredjenu nit
    __asm__ volatile("csrw sepc, ra");
    __asm__ volatile("sret");
}

void Riscv::handleSupervisorTrap1() {
    uint64 temp;
    uint64 kod;
    //citamo scause - razlog



    temp = r_scause();
    //iz a0 upisano u kod

    __asm__ volatile("mv %0, a0" : "=r" (kod));

    //8 to je user mode, 9 je sistemski mode
    if(temp == 0x0000000000000008UL || temp == 0x0000000000000009UL){
        //+4 jer se gleda instrukcija
        uint64 volatile pc = r_sepc() + 4;
        uint64 volatile status = r_sstatus();

        if(kod == 0x01){
            void* ret;
            size_t arg;

            __asm__ volatile("mv %0, a1" : "=r"(arg));
            ret = MemoryAllocator::mem_alloc(arg);
            //moguce je da se u medjuvremenu uprlja a0, ovako smo sigurni u njenu vrednost
            __asm__ volatile("mv a0, %0" :: "r" (ret));
        }
        else if(kod == 0x02){
            int ret;
            void* arg;
            __asm__ volatile("mv %0, a1" : "=r"(arg));
            ret = MemoryAllocator::mem_free(arg);
            __asm__ volatile("mv a0, %0" :: "r" (ret));
        }
        else if(kod == 0x11){
            int ret = -11;
            //thread_t* handle, void(*start_routine)(void*), void* arg
            //CCB** je thread_t*
            CCB** prviArg;
            CCB::Body drugiArg;
            void* treciArg;
            //__asm__ volatile("mv %0, a1" : "=r"(prviArg));
            /*
            __asm__ volatile("mv %0, a2" : "=r"(drugiArg));
            __asm__ volatile("mv %0, a3" : "=r"(treciArg));*/
            __asm__ volatile("ld s1, 11*8(fp)");
            __asm__ volatile("ld s2, 12*8(fp)");
            __asm__ volatile("ld s3, 13*8(fp)");
            void* stek = MemoryAllocator::mem_alloc(sizeof(uint64)*DEFAULT_STACK_SIZE);
            // static void createCoroutine(CCB** h, Body body, void *arg, void* stek);
            __asm__ volatile("mv %0, s1" : "=r"(prviArg));
            __asm__ volatile("mv %0, s2" : "=r"(drugiArg));
            __asm__ volatile("mv %0, s3" : "=r"(treciArg));

            CCB::createCoroutine(prviArg,drugiArg, treciArg, stek, DEFAULT_TIME_SLICE);
            if(prviArg != 0) ret = 0;
            __asm__ volatile("mv a0, %0" :: "r" (ret));

        }else if(kod == 0x12){
            int ret = 0;
            CCB::running->setFinished(true);
            CCB::dispatch();
            __asm__ volatile("mv a0, %0" :: "r" (ret));
        }else if(kod == 0x13){
            CCB::dispatch();
            //dispatch treba posle svakog s.poziva pa ce se raditi na kraju petlje
        }else if(kod == 0x14){
            CCB* handle;
            __asm__ volatile("mv %0, a1" : "=r"(handle));
            CCB::join(handle);

        }else if(kod == 0x21) {
            unsigned ret = 0;
            sem_t* handle = nullptr;
            unsigned init;
            __asm__ volatile("ld s1, 11*8(fp)");
            __asm__ volatile("ld s2, 12*8(fp)");
            __asm__ volatile("mv %0, s1" : "=r"(handle));
            __asm__ volatile("mv %0, s2" : "=r"(init));

            *handle = MySemaphore::napraviSEmafor(init);

            __asm__ volatile("mv a0, %0" :: "r" (ret));

        }else if(kod == 0x22) {
            int ret = 0;
            sem_t id  = nullptr;
            __asm__ volatile("mv %0, a1" : "=r"(id));
            id->MySemaphore::oslobodiSemefor(id);
            __asm__ volatile("mv a0, %0" :: "r" (ret));

        }else if(kod == 0x23) {
            int ret = 0;
            sem_t id = nullptr;
            __asm__ volatile("mv %0, a1" : "=r"(id));
            id->MySemaphore::wait(id);
            __asm__ volatile("mv a0, %0" :: "r" (ret));

        }else if(kod == 0x24) {
            int ret = 0;
            sem_t id = nullptr;
            __asm__ volatile("mv %0, a1" : "=r"(id));
            id->MySemaphore::signal(id);
            __asm__ volatile("mv a0, %0" :: "r" (ret));
        } else if(kod == 0x31){
            int ret = 0;
            time_t vreme;
            __asm__ volatile("mv %0, a1" : "=r"(vreme));
            CCB::running->uspavaj(vreme);
            //CCB::uspavaj(vreme);
            __asm__ volatile("mv a0, %0" :: "r" (ret));
        }

        else if(kod == 0x41){
            char c;
            c = MyKonzola::input->get();
            __asm__ volatile("mv a0, %0" :: "r" (c));
        }else if(kod == 0x42){
            char c;
            __asm__ volatile("mv %0, a1" : "=r"(c));
            MyKonzola::output->put(c);
        }

        __asm__ volatile("sd a0,10*8(s0)");

        w_sstatus(status);
        w_sepc(pc);
        mc_sip(SIP_SSIE);

    }

    else {
        // unexpected trap cause
        if (temp == 0x0000000000000002UL){
            printString("Error 2\n");
        }
        if (temp == 0x0000000000000005UL){
            printString("Error 5\n");
        }
        if (temp == 0x0000000000000007UL){
            printString("Error 7\n");

        }
    }

}
void Riscv::handleSupervisorTrap2() {
    ElemT *trenutni = CCB::head;
    while (trenutni){
        trenutni->data->vremeZaSpavanjeUListi--;
        if(trenutni->data->vremeZaSpavanjeUListi == 0){
            if(trenutni == CCB::head){
                CCB::head = CCB::head->next;
            }
            trenutni->data->unblock();
            Scheduler::put(trenutni->data);
            if(trenutni->prev) {
                trenutni->prev->next = trenutni->next;
            }
            if(trenutni->next){
                trenutni->next->prev=trenutni->prev;
            }

        }
        trenutni= trenutni->next;

    }
    if(CCB::head == nullptr){
        CCB::tail = nullptr;
    }
    CCB::timeSliceCounter++;
    if (CCB::timeSliceCounter >= CCB::running->getTimeSlice())
    {
        uint64 volatile sepc = r_sepc();
        uint64 volatile sstatus = r_sstatus();
        CCB::timeSliceCounter = 0;
        CCB::dispatch();
        w_sstatus(sstatus);
        w_sepc(sepc);
    }
    mc_sip(SIP_SSIE);
}

void Riscv::handleSupervisorTrap3() {
    int r = plic_claim();
    if(r == CONSOLE_IRQ){
        //provera da li je ready
        while ((*(char*)CONSOLE_STATUS) & CONSOLE_RX_STATUS_BIT){
            char c = *(char*) CONSOLE_RX_DATA;
            MyKonzola::input->put(c);

        }
    }

    plic_complete(r);
}