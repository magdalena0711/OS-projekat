//
// Created by os on 5/20/23.
//
#include "../h/syscall_cpp.hpp"
#include "../lib/console.h"

void* operator new(uint64 size){
    return MemoryAllocator::mem_alloc(size);
}
void operator delete(void* ptr){
    MemoryAllocator::mem_free(ptr);
}
void* operator new[](uint64 size){
    return MemoryAllocator::mem_alloc(size);
}
void operator delete[](void* ptr){
    MemoryAllocator::mem_free(ptr);
}
Thread::Thread (void (*body)(void*), void* arg){
    myHandle->staviUSc = false;
    thread_create(&myHandle, body, arg);
}

void Thread::dispatch() {
    thread_dispatch();
}
Thread::~Thread() {
    myHandle->setFinished(true);
    mem_free(myHandle->dohvatiStek());
    mem_free(myHandle->mojSemaforcic);
    mem_free(myHandle);
}

int Thread::start() {

    Scheduler::put(myHandle);
    return 0;
}

void Thread::join() {
    thread_join(myHandle);
}

void Thread::wraperZaRun(void *rucka) {
    Thread* tcb = (Thread*)rucka;
    tcb->run();
}

//VRATITI SE NA OVO
Thread::Thread() {
    myHandle->staviUSc = false;
    thread_create(&myHandle, &wraperZaRun, this);
}

int Thread::sleep(time_t t) {
    time_sleep(t);
    return 0;
}

int Semaphore::signal() {
    sem_signal(myHandle);
    return 0;
}

int Semaphore::wait() {
    sem_wait(myHandle);
    return 0;
}

Semaphore::Semaphore(unsigned int init) {
    sem_open(&myHandle, init);
    //VRATITI SE OVDE
}

Semaphore::~Semaphore() {
    //VRATITI SE OVDE
    sem_close(myHandle);
    mem_free(myHandle);
}

void PeriodicThread::terminate() {
    CCB* rucka = myHandle;
    rucka->setFinished(true);
    thread_dispatch();
}

PeriodicThread::PeriodicThread(time_t period):Thread(){

    this->period = period;
}


char Console::getc() {

    return ::getc();

}


void Console::putc(char c) {
    ::putc(c);
}