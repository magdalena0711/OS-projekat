
#include "../h/ccb.hpp"
#include "../h/riscv.hpp"
#include "../h/syscall_c.h"

uint64 CCB::timeSliceCounter = 0;
CCB* CCB::running = nullptr;
ElemT* CCB::head = nullptr;
ElemT* CCB::tail = nullptr;
bool CCB::staviUSc = true;


void CCB::createCoroutine(CCB** h, Body body, void *arg, void* stek, uint64 timeSlice) {


    CCB* rucka = (CCB*)MemoryAllocator::mem_alloc(sizeof(CCB));
    rucka->mojSemaforcic = MySemaphore::napraviSEmafor(0);

    rucka->body = body;
    rucka->arg = arg;
    rucka->timeSlice = timeSlice;
    rucka->stek = (uint64*)stek;
    rucka->finished = false;
    rucka->unblock();
    rucka->context = {(uint64)&wraper, (uint64)&rucka->stek[DEFAULT_STACK_SIZE]};
    rucka->sledeciZaScheduler = nullptr;

    rucka->sisNIt = false;
    /*rucka->context.ra = (uint64)&wraper;
    uint64 *stek_ptr = (uint64 *)stek;
    rucka->context.sp = stek_ptr[DEFAULT_STACK_SIZE];*/
    *h= rucka;
    if (body != nullptr && CCB::staviUSc == true) { Scheduler::put(*h); }
}

CCB::CCB(CCB::Body body, void *arg) {
    this->body = body;
    this->arg = arg;
}

CCB::CCB(Body body, void* arg, void* stek) {
    this->body = body;
    this->finished = false;
    this->stek = (uint64*)stek;
    this->arg = arg;
    this->isParentWaitaing = false;

    context.ra = (uint64)&wraper;
    uint64 *stek_ptr = (uint64 *)stek;
    context.sp = stek_ptr[DEFAULT_STACK_SIZE];
    //if (body != nullptr) { Scheduler::put(this); }

}

int CCB::uspavaj(time_t vreme) {
    //ona koja poziva se uspava, blokira

    if(vreme <= 0) return 0;

    CCB::running->setBlocked();
    CCB::running->vremeZaSpavanjeUListi = vreme;
    ElemT* zaUbacivanje = (ElemT*)MemoryAllocator::mem_alloc(sizeof(ElemT));
    zaUbacivanje->data = CCB::running;
    zaUbacivanje->next = nullptr;
    zaUbacivanje->prev = nullptr;
    if(tail){
        tail->next = zaUbacivanje;
        tail = zaUbacivanje;
    }else{

        tail = head = zaUbacivanje;
    }

    CCB::dispatch();
    return 0;
}

void CCB::wraper() {
    //u sepc je upisan ra
    Riscv::popSppSpie();
    /*
    running->setBody(running->getArg());
*/
    running->body(running->arg);
    running->setFinished(true);

    running->mojSemaforcic->oslobodiSemefor(running->mojSemaforcic);


    thread_dispatch();
}


void CCB::dispatch() {
    CCB* old = running;
    if(!old->isFinished() && !old->blocked){
        Scheduler::put(old);
    }

    running = Scheduler::get();
    timeSliceCounter = 0;
    CCB::contextSwitch(&old->context, &running->context);
}

void CCB::join(thread_t handle) {
    if(handle->isFinished() == false){
        handle->mojSemaforcic->wait(handle->mojSemaforcic);
    }

}