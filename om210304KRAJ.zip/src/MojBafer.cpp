//
// Created by os on 6/7/23.
#include "../h/MojBafer.hpp"
#include "../h/syscall_c.h"

MojBafer *MojBafer::inicijalizuj() {
    MojBafer* baf = (MojBafer*)MemoryAllocator::mem_alloc(sizeof(MojBafer));
    baf->itemAvailable = MySemaphore::napraviSEmafor(0);
    baf->spaceAvailable = MySemaphore::napraviSEmafor(1024);
    baf->size = 0;
    baf->head = 0;
    baf->tail = 0;
    return baf;

}

void MojBafer::put(char c) {
    //ako je veci, nece se ubacivati, MAX velicina je 256
    spaceAvailable->wait(spaceAvailable);
    bafer[tail] = c;
    tail = (tail + 1) % 1024;
    size++;
    itemAvailable->signal(itemAvailable);
}

char MojBafer::get() {
    itemAvailable->wait(itemAvailable);
    char c = bafer[head];
    head = (head + 1) % 1024;
    size--;
    spaceAvailable->signal(spaceAvailable);
    return c;
}

//
