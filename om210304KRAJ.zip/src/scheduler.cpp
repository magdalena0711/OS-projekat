#include "../h/scheduler.hpp"
#include "../h/list.hpp"
#include "../h/MemoryAllocator.hpp"

/*
List<CCB> Scheduler::spremneKorutineRed;

CCB* Scheduler::get() {


    return spremneKorutineRed.ukloniPrvi();
}

void Scheduler::put(CCB *ccb) {
    spremneKorutineRed.dodajPoslednji(ccb);
}*/

CCB* Scheduler::head = nullptr;
CCB* Scheduler::tail = nullptr;

CCB *Scheduler::get()
{
/*
    if(head == nullptr) {
        return nullptr;
    }

    Elem *elem = head;
    head = head->next;
    if(head == nullptr) {
        tail = nullptr;
    }
    CCB *pom = elem->data;
    return pom;
     */
    if(head == nullptr){
        return nullptr;
    }
    CCB* elem = head;
    head = head->sledeciZaScheduler;
    if(head == nullptr){
        tail = nullptr;
    }
    elem->sledeciZaScheduler = nullptr;
    return elem;
}

void Scheduler::put(CCB *tcb)
{
/*
    Elem *elem = (Elem*)MemoryAllocator::mem_alloc(sizeof(Elem));
    elem->data = tcb;
    elem->next = nullptr;
    //uvezivanje u listu
    if(tail== nullptr){
        head = tail = elem;
    }else{
        tail->next = elem;
        tail = elem;
    }
*/
    tcb->sledeciZaScheduler = nullptr;
    if(tail == nullptr){
        head = tail = tcb;
    } else{
        tail->sledeciZaScheduler = tcb;
        tail = tcb;
    }
}
