//
// Created by os on 6/19/23.
//

#include "../h/MyKonzola.hpp"


MojBafer* MyKonzola::input = nullptr;
MojBafer* MyKonzola::output = nullptr;

void slanjeNaKontroler(){
    while (true){
        //provera da li je ready
        while ((*(char*)CONSOLE_STATUS) & CONSOLE_TX_STATUS_BIT){
            char c = MyKonzola::output->get();
            *(char*) CONSOLE_TX_DATA = c;
        }
    }
}
