#include "../h/ccb.hpp"
#include "../h/riscv.hpp"
#include "../h/syscall_c.h"
#include "../h/MemoryAllocator.hpp"
#include "../test/printing.hpp"
#include "../h/MySemaphore.hpp"
#include "../h/MojBafer.hpp"
#include "../h/MyKonzola.hpp"

int zbir;
sem_t semaforcic;
int** matrica;
int brKolona;
int i, j, h;
int* p;

extern void userMain();
extern void Threads_C_API_test();
extern void Threads_CPP_API_test();
extern void producerConsumer_C_API();
extern void producerConsumer_CPP_Sync_API();
extern  void testSleeping();
extern void slanjeNaKontroler();


int main(){

    MemoryAllocator::memInicijalizacija();

    Riscv::w_stvec((uint64) (&Riscv::vektor)|1);



    CCB* main_c = nullptr;
    //CCB** main_cor = &main_c;
    CCB* nit = nullptr;
    CCB** nit_cor = &nit;
    CCB* nit1 = nullptr;
    CCB** nit_cor1 = &nit1;

    MyKonzola::input = MojBafer::inicijalizuj();
    MyKonzola::output = MojBafer::inicijalizuj();


    CCB::createCoroutine(&main_c, nullptr, nullptr, nullptr, DEFAULT_TIME_SLICE);
    CCB::running = main_c;
    main_c->sisNIt = true;
    void* stek2 = MemoryAllocator::mem_alloc(sizeof(uint64)*DEFAULT_STACK_SIZE);
    void* stek1 = MemoryAllocator::mem_alloc(sizeof(uint64)*DEFAULT_STACK_SIZE);


    CCB::createCoroutine(nit_cor, (void(*)(void*))&userMain, nullptr, stek1, DEFAULT_TIME_SLICE);
    CCB::createCoroutine(nit_cor1, (void(*)(void*))&slanjeNaKontroler, nullptr, stek2, DEFAULT_TIME_SLICE) ;
    (*nit_cor1)->sisNIt = true;

    Riscv::ms_sstatus(Riscv::SSTATUS_SIE);


    while((*nit_cor)->isFinished() == false){
        thread_dispatch();
    }


    MyKonzola::input->dohvatiSemafor()->oslobodiSemefor(MyKonzola::input->dohvatiSemafor());
    MyKonzola::output->dohvatiSemafor()->oslobodiSemefor(MyKonzola::output->dohvatiSemafor());

    mem_free(MyKonzola::input->dohvatiSemafor());
    mem_free(MyKonzola::output->dohvatiSemafor());
    mem_free(stek1);
    mem_free(stek2);
    mem_free(MyKonzola::input);
    mem_free(MyKonzola::output);
    mem_free((*nit_cor1)->mojSemaforcic);
    mem_free((main_c)->mojSemaforcic);
    mem_free(*nit_cor);
    mem_free(*nit_cor1);
    mem_free(main_c);

    return 0;

}