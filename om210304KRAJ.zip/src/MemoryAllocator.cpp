#include "../h/MemoryAllocator.hpp"

MemoryAllocator::FreeMem* MemoryAllocator::headFree;

//IDEJA JE PREUZETA SA KOLOKVIJUMA

//moramo da inicijalizujemo pocetak
void MemoryAllocator::memInicijalizacija() {
    headFree = (MemoryAllocator::FreeMem*)HEAP_START_ADDR;
    headFree->size = (size_t)HEAP_END_ADDR - (size_t)HEAP_START_ADDR;
    headFree->next = nullptr;
    headFree->prev = nullptr;
}

//pokusavamo trenutni da spojimo sa njegovim sledecim
void tryToJoin(MemoryAllocator::FreeMem *current) {
    if(current == nullptr) return;

    //proveravamo da li se nadovezuju jedan na drugi tj. da li je pocetak drugog na kraju prvog
    if(current->next && (char*)current + current->size == (char*)(current->next)){
        //ako se nadovezuju, dolazi do spajanja
        current->size += current->next->size;   //povecava se velicina za velicinu togsegmenta sa kojim se desava spajanje
        current->next = current->next->next;
        if(current->next){
            current->next->prev = current;
        }
    }
    return;
}

void *MemoryAllocator::mem_alloc(size_t size) {
    if(size <= 0 || headFree == nullptr) return nullptr;

    size_t novaVelicina = size + sizeof(FreeMem);
    if(novaVelicina > MEM_BLOCK_SIZE){
        //ako je veca od jednog bloka, mora da uzme jos jedan, tj mora biti poravnato
        novaVelicina = ((novaVelicina / MEM_BLOCK_SIZE) + 1) * MEM_BLOCK_SIZE;
    }else{
        novaVelicina = MEM_BLOCK_SIZE;
    }
    //dodajemo velicinu zaglavlja u svakom slucaju



    FreeMem* trenutni = headFree;
    //first-fit
    while(trenutni != nullptr && trenutni->size < novaVelicina ){
        trenutni = trenutni->next;
    }

    void *zaVracanje = nullptr;
    //pronadjen je odgovarajuci segment
    if(trenutni == nullptr){
        return nullptr;
    }
    if(trenutni->size > novaVelicina){
        if(trenutni->size - novaVelicina < sizeof(FreeMem)){
            if(trenutni->prev) trenutni->prev->next= trenutni->next;
            else headFree = trenutni->next;
            if(trenutni->next) trenutni->next->prev = trenutni->prev;

        } else{
            FreeMem* noviFragment = (FreeMem*)((char*)trenutni+ novaVelicina);
            if(trenutni->prev) trenutni->prev->next = noviFragment;
            else{
                headFree = noviFragment;
            }
            //skinula minus
            if(trenutni->next) trenutni->next->prev = noviFragment;
            noviFragment->prev = trenutni->prev;
            noviFragment->next = trenutni->next;
            noviFragment->size = (size_t)(trenutni->size - novaVelicina);
            trenutni->size = novaVelicina;

            /*trenutni->size = novaVelicina;
            trenutni->next = noviFragment;
            noviFragment->prev = trenutni->prev;
            noviFragment->next = trenutni->next;
            noviFragment->size = trenutni->size - novaVelicina;*/
        }
        trenutni->next = trenutni->prev = nullptr;
        zaVracanje = (char*)trenutni + sizeof(FreeMem);
    }
    return zaVracanje;
}
//vraca 0 u slucaju uspeha, negativnu vrednost u slucaju greske

int MemoryAllocator::mem_free(void *address) {
    address = (char*)address - sizeof(FreeMem);
    //ako je adresa razlicita od povratne vrednosti mem_alloc-a, greska!
    if(address == nullptr) return -1;

    FreeMem* current = 0;
    //trazimo mesto gde da ubacimo novi segment
    if(!headFree || (char*)address < (char*) headFree) current = 0;
    else{
        for(current = headFree; current->next && (char*)address > (char*)(current->next); current = current->next);
    }

    FreeMem* segNew = (FreeMem*) address;
    //segNew->size = current->size;
    //fali velicina, proveriti ovaj deo!!!
    //ubacivanje novog segmenta nakon trenutnog
    segNew->prev = current;
    if(current) segNew->next = current->next;
    else{
        segNew->next = headFree;
    }
    if(segNew->next){
        segNew->next->prev = segNew;
    }
    if(current) current->next = segNew;
    else{
        headFree = segNew;
    }
    tryToJoin(segNew);
    tryToJoin(current);
    return 0;
}

