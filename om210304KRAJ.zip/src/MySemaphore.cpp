//
// Created by os on 6/4/23.
//

#include "../h/MySemaphore.hpp"
#include "../h/scheduler.hpp"


MySemaphore::MySemaphore(unsigned int v) {
    this->val = v;
}

int MySemaphore::wait(sem_t rucka) {
    rucka->val--;
    if(rucka->val< 0){
        CCB::running->setBlocked();

        ElemS* zaUbacivanje = (ElemS*)MemoryAllocator::mem_alloc(sizeof(ElemS));
        zaUbacivanje->data = CCB::running;
        zaUbacivanje->next = nullptr;
        if(rucka->tail){
            rucka->tail->next = zaUbacivanje;
            rucka->tail = zaUbacivanje;
        }
        else{
            rucka->tail = rucka->head = zaUbacivanje;
        }
        CCB::dispatch();
    }

    return 1;
}

int MySemaphore::signal(sem_t rucka) {
    rucka->val++;
    if(rucka->val<= 0){

        if(rucka->head){
            thread_t t = rucka->head->data;
            rucka->head = rucka->head->next;
            if(rucka->head == nullptr){
                rucka->tail = nullptr;
            }
            t->unblock();
            Scheduler::put(t);
        }
    }
    return 0;
}

void MySemaphore::oslobodiSemefor(sem_t rucka) {
    while(rucka->head){
        thread_t t = rucka->head->data;
        rucka->head = rucka->head->next;
        t->unblock();
        Scheduler::put(t);
    }
}

MySemaphore *MySemaphore::napraviSEmafor(int v) {

    MySemaphore *pom = (MySemaphore*)MemoryAllocator::mem_alloc(sizeof(MySemaphore));
    pom->head = nullptr;
    pom->tail = nullptr;
    pom->val = v;
    return pom;
}
