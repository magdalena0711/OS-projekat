
#ifndef PROJECT_BASE_SCHEDULER_HPP
#define PROJECT_BASE_SCHEDULER_HPP

#include "list.hpp"
#include "ccb.hpp"
class CCB;


/*
class Scheduler{
private:
    static List<CCB> spremneKorutineRed;

public:
    static CCB *get();
    static void put(CCB* ccb);
};*/
/*
struct Elem{
    CCB *data;
    Elem *next;
};*/
class Scheduler{
private:
    static CCB* head;
    static CCB* tail;

    //static Elem *head;
    //static Elem *tail;

public:
    static CCB *get();
    static void put(CCB *ccb);

};

#endif //PROJECT_BASE_SCHEDULER_HPP