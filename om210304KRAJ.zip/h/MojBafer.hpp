//
// Created by os on 6/7/23.
//

#ifndef PROJECT_BASE_MOJBAFER_HPP
#define PROJECT_BASE_MOJBAFER_HPP

#include "MySemaphore.hpp"

class MojBafer{
public:/*
    void* operator new(uint64 size){
        return MemoryAllocator::mem_alloc(size);
    }
    void operator delete(void* ptr){
        MemoryAllocator::mem_free(ptr);
    }
    void* operator new[](uint64 size){
        return MemoryAllocator::mem_alloc(size);
    }
    void operator delete[](void* ptr){
        MemoryAllocator::mem_free(ptr);
    }
*/
    static MojBafer* inicijalizuj();
    void put(char);
    char get();

    sem_t dohvatiSemafor(){return itemAvailable;}
private:
    sem_t itemAvailable, spaceAvailable;
    char bafer[1024];
    int size, head, tail;
};


#endif //PROJECT_BASE_MOJBAFER_HPP
