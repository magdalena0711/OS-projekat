//
// Created by os on 6/19/23.
//

#ifndef PROJECT_BASE_MYKONZOLA_HPP
#define PROJECT_BASE_MYKONZOLA_HPP

#include "MojBafer.hpp"

class MyKonzola {
public:
    static MojBafer* output, *input;
};


#endif //PROJECT_BASE_MYKONZOLA_HPP
