#ifndef PROJECT_BASE_LIST_HPP
#define PROJECT_BASE_LIST_HPP

#include "MemoryAllocator.hpp"

template <typename T>
class List{
private:
    struct Elem{
        T *data;
        Elem* next;
        Elem(T* data, Elem* next): data(data), next(next){}

    };

    Elem *head, *tail;

public:/*
    void* operator new(uint64 size){
        return MemoryAllocator::mem_alloc(size);
    }
    void operator delete(void* ptr){
        MemoryAllocator::mem_free(ptr);
    }
    void* operator new[](uint64 size){
        return MemoryAllocator::mem_alloc(size);
    }
    void operator delete[](void* ptr){
        MemoryAllocator::mem_free(ptr);
    }
*/
    List():head(0), tail(0){}

    List(const List<T> &) = delete;
    List<T> &operator=(const List<T> &) = delete;

    void dodajPrvi(T* data){
        Elem* elem= (Elem*)MemoryAllocator::mem_alloc(sizeof(Elem));
        elem->data = data;
        elem->next = head;
        head = elem;
        if(!tail) {
            tail = head;
        }
    }

    void dodajPoslednji(T* data){
        Elem *elem = (Elem*)MemoryAllocator::mem_alloc(sizeof(Elem));
        elem->data = data;
        elem->next = 0;
        if(tail){
            tail->next = elem;
            tail = elem;
        }
        else{
            head = tail = elem;
        }
    }

    T* ukloniPrvi(){
        if(!head) {
            return nullptr;
        }
        Elem* elem = head;
        head = head->next;
        if(!head){
            tail = nullptr;
        }

        T* ret = elem->data;
        MemoryAllocator::mem_free(elem);
        return ret;
    }

    T* pogledajPrvi(){
        if(!head){
            return nullptr;
        }
        return head->data;
    }

    T* ukloniPoslednji(){
        if(!head){
            return nullptr;
        }
        Elem* prethodni = nullptr;

        for(Elem* tren = head; tren && tren!= tail; tren = tren->next){
            prethodni = tren;
        }
        Elem* elem = tail;

        if(prethodni) {
            prethodni->next = nullptr;
        }
        else{
            head = nullptr;
        }
        tail = prethodni;
        T* ret = elem->data;
        MemoryAllocator::mem_free(elem);
        return ret;
    }

    T* pogledajPoslednji(){
        if(!tail){
            return nullptr;
        }
        return tail->data;
    }

};

#endif //PROJECT_BASE_LIST_HPP