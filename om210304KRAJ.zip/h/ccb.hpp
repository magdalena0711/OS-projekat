
#ifndef PROJECT_BASE_CCB_HPP
#define PROJECT_BASE_CCB_HPP

#include "../lib/hw.h"
#include "scheduler.hpp"
#include "MemoryAllocator.hpp"
#include "MySemaphore.hpp"


class CCB;
class MySemaphore;
struct ElemT{
    CCB *data;
    ElemT *next;
    ElemT* prev;
};



class CCB{

public:
    void* operator new(uint64 size){
        return MemoryAllocator::mem_alloc(size);
    }
    void operator delete(void* ptr){
        MemoryAllocator::mem_free(ptr);
    }
    void* operator new[](uint64 size){
        return MemoryAllocator::mem_alloc(size);
    }
    void operator delete[](void* ptr){
        MemoryAllocator::mem_free(ptr);
    }


    bool sisNIt = false;
    static bool staviUSc;
    ~CCB(){ delete[] stek;}
    bool isFinished() const {return finished;}
    void setFinished(bool v){finished = v;}
    bool isBlocked() const {return blocked;}
    void setBlocked(){ blocked = true;}
    void unblock(){ blocked = false;}

    //pokazivac na funkciju nad kojom se stvara nit, tj void* je nasa nit
    using Body = void(*) (void*);

    void setBody(void* b){
    //moja funkcija prima argument b (B prima b)
        body(b);
    }

    void setArg(void *a){
        arg = a;
    }

    void* getArg(){
        return this->arg;
    }

    Body getBody(){
        return this->body;
    }

    MySemaphore* mojSemaforcic;


    static ElemT *head;
    static ElemT *tail;

    CCB* sledeciZaScheduler;

    time_t vremeZaSpavanjeUListi;
    //body je funkcija
    //arg je nit
    static void createCoroutine(CCB** h, Body body, void *arg, void* stek, uint64 timeSlice);
    static void yield();
    static CCB *running;
    int uspavaj(time_t vreme);
    CCB(Body body, void* arg);
    static void dispatch();
    static void join(CCB* handle);

    uint64 getTimeSlice() const {return timeSlice;}
    static uint64 timeSliceCounter;

    uint64* dohvatiStek(){return stek;}

    static void wraper();
private:

    explicit CCB(Body body, void* arg, void* stek);

    struct Context
    {
        uint64 ra;
        uint64 sp;
    };

    void* arg; //nit
    Body body;
    uint64 *stek;
    Context context;
    bool finished;
    //CCB* parent;
    bool blocked;
    uint64 timeSlice;

    bool isParentWaitaing;
    static void contextSwitch(Context *oldContext, Context *runningContext);
    //postavlja kontekst niti


    static uint64 constexpr STACK_SIZE = 1024;
    static uint64 constexpr TIME_SLICE = 2;
};


#endif //PROJECT_BASE_CCB_HPP
