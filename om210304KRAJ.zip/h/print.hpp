//
// Created by os on 4/22/23.
//

#ifndef PROJECT_BASE_PRINT_HPP
#define PROJECT_BASE_PRINT_HPP

#include "../lib/hw.h"

extern void printString(char const *string);
extern void printInteger(uint64 integer);

#endif //PROJECT_BASE_PRINT_HPP
