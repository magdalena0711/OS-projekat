//
// Created by os on 5/27/23.
//

#ifndef PROJECT_BASE_MYSEMAPHORE_HPP
#define PROJECT_BASE_MYSEMAPHORE_HPP

#include "list.hpp"
#include "syscall_cpp.hpp"


class Semaphore;
struct ElemS{
    CCB *data;
    ElemS *next;
};
class MySemaphore{
public:
    void* operator new(uint64 size){
        return MemoryAllocator::mem_alloc(size);
    }
    void operator delete(void* ptr){
        MemoryAllocator::mem_free(ptr);
    }
    void* operator new[](uint64 size){
        return MemoryAllocator::mem_alloc(size);
    }
    void operator delete[](void* ptr){
        MemoryAllocator::mem_free(ptr);
    }

private:
    bool lock;
    typedef MySemaphore* sem_t;
    int val;

    //NITI KOJE CEKAJU

    friend class Semaphore;
    //Semaphore* mojSemafor;
public:

    ElemS *head;
    ElemS *tail;
    void oslobodiSemefor(sem_t rucka);
    static MySemaphore* napraviSEmafor(int v);
    int wait(sem_t rucka);
    int signal(sem_t rucka);
    int dohvatiVrednost() const{return val;}
    //ZABRANA DA SE PRAVI SEMAFOR BEZ VAL
    MySemaphore(unsigned v);

};


#endif //PROJECT_BASE_MYSEMAPHORE_HPP
