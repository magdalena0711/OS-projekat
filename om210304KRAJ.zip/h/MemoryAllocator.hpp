#ifndef PROJECT_BASE_MEMORYALLOCATOR_HPP
#define PROJECT_BASE_MEMORYALLOCATOR_HPP
#include "../lib/hw.h"


class MemoryAllocator{
public:
    struct FreeMem{
        FreeMem *next;
        FreeMem *prev;
        size_t size;
    };

private:
    MemoryAllocator(){}

public:
    static FreeMem *headFree;   //mora staticka da bude jer vazi za celu memoriju
    static void* mem_alloc(size_t size);
    static int mem_free(void*);
    static void memInicijalizacija();
};

#endif //PROJECT_BASE_MEMORYALLOCATOR_HPP